package com.opencodez.util;

public class Constants {
	
	public static final String API_KEY = "api.key";
	public static final String API_BASE_URL = "currency.api.base.uri";
	public static final String CACHE_EXPIRY = "cache.expiry";
}
