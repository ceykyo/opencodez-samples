package com.opencodez.microservice.springclientemployerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringClientEmployerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringClientEmployerServiceApplication.class, args);
	}
}
