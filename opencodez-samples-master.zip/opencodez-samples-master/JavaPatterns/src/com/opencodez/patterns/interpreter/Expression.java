package com.opencodez.patterns.interpreter;

public interface Expression {
	public int interpret(InterpreterEngine ie);
}
