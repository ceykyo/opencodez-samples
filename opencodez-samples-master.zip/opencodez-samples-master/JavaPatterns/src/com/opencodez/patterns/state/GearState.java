package com.opencodez.patterns.state;

public interface GearState {
	public void changeGear();
	public void accelarate(int speed);
}
