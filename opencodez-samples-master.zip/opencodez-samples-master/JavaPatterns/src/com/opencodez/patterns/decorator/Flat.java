package com.opencodez.patterns.decorator;

public interface Flat {
	public String getSpecification();
}
