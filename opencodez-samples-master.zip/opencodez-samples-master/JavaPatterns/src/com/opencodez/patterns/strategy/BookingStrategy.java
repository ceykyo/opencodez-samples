package com.opencodez.patterns.strategy;

public interface BookingStrategy {
	public double getFare();
}
