package com.opencodez.main;

import com.opencodez.patterns.command.client.ClientCustomer;

public class CommandPatternTest {

	public static void main(String[] args) {

		new ClientCustomer();
		
	}

}
