/**
 * 
 */
package com.opencodez.repo;

import java.util.List;

import com.opencodez.domain.UserModel;

/**
 * @author pavan.solapure
 *
 */
public interface GenericRepo {
	
	List<UserModel> getUserModel();
	
	
}
